import java.util.*;
//Options definition.
class Background
{
	String first,middle,last,numbers="0123456789",from1,to1;
	int type,from,to,price,len=4,ticketno;
	long phone_number;
	Scanner sc=new Scanner(System.in);

	//Ticket booking.

	void Bookticket()
	{
		//User information
		System.out.println("--------------------WELCOM TO TICKET BOOKING SERVICE--------------------");
		System.out.println("Enter FIRST NAME :");
		first=sc.next();
		System.out.println("Enter MIDDLE NAME :");
		middle=sc.next();
		System.out.println("Enter LAST NAME :");
		last=sc.next();
		System.out.println("Enter PHONE NUMBER :");	
		phone_number=sc.nextLong();
		System.out.println("Enter 1 for FIEST CLASS.\nEnter 2 for SECOND CLASS.\nEnter 3 for LOCAL CLASS.");
		System.out.println("Enter TRAIN TYPE :");
		type=sc.nextInt();

		switch(type)
		{
			//First class.

			case 1:
				System.out.println("Enter 1 for KOLHAPUR.\nEnter 2 for PUNE.\nEnter 3 for MUMBAI.\nEnter 4 for NAGPUR.\nEnter 5 for BENGALOR.");
				System.out.println("FROM :");
				from=sc.nextInt();
				System.out.println("TO :");
				to=sc.nextInt();

				if(((from==1)&&(to==2))||((from==2)&&(to==1)))
				{
					price=300+200;
					System.out.println("PRICE :"+price);
				}
				else if(((from==1)&&(to==3))||((from==3)&&(to==1)))
				{
					price=300+300;
					System.out.println("PRICE :"+price);
				}
				else if(((from==1)&&(to==4)||(from==4)&&(to==1)))
				{
					price=300+400;
					System.out.println("PRICE :"+price);
				}
				else if(((from==1)&&(to==5))||((from==5)&&(to==1)))
				{
					price=300+500;
					System.out.println("PRICE :"+price);
 				}
				else if(((from==2)&&(to==3))||((from==3)&&(to==2)))
				{
					price=300+600;
					System.out.println("PRICE :"+price);
				}
				else if(((from==2)&&(to==4))||((from==4)&&(to==2)))
				{
					price=300+700;
					System.out.println("PRICE :"+price);
				}
				else if(((from==2)&&(to==5))||((from==5)&&(to==2)))
				{
					price=300+700;
					System.out.println("PRICE :"+price);
				}
				else if(((from==3)&&(to==4))||((from==4)&&(to==3)))
				{
					price=300+700;
					System.out.println("PRICE :"+price);
				}
				else if(((from==3)&&(to==5))||((from==5)&&(to==3)))
				{
					price=300+700;
					System.out.println("PRICE :"+price);
				}
				else if(((from==4)&&(to==5))||((from==5)&&(to==4)))
				{
					price=300+700;
					System.out.println("PRICE :"+price);
				}
				else
				{
					System.out.println("WRONG DESTINETION ENTERD.");
				}
			break;

			//Second class.

			case 2:
				System.out.println("Enter 1 for KOLHAPUR.\nEnter 2 for PUNE.\nEnter 3 for MUMBAI.\nEnter 4 for NAGPUR.\nEnter 5 for BENGALOR.");
				System.out.println("FROM :");
				from=sc.nextInt();
				System.out.println("TO :");
				to=sc.nextInt();

				if(((from==1)&&(to==2))||((from==2)&&(to==1)))
				{
					price=200+200;
					System.out.println("PRICE :"+price);
				}
				else if(((from==1)&&(to==3))||((from==3)&&(to==1)))
				{
					price=200+300;
					System.out.println("PRICE :"+price);
				}
				else if(((from==1)&&(to==4))||((from==4)&&(to==1)))
				{
					price=200+400;
					System.out.println("PRICE :"+price);
				}
				else if(((from==1)&&(to==5))||((from==5)&&(to==1)))
				{
					price=200+500;
					System.out.println("PRICE :"+price);
				}
				else if(((from==2)&&(to==3))||((from==3)&&(to==2)))
				{
					price=200+600;
					System.out.println("PRICE :"+price);
				}
				else if(((from==2)&&(to==4))||((from==4)&&(to==2)))
				{
					price=200+700;
					System.out.println("PRICE :"+price);
				}
				else if(((from==2)&&(to==5))||((from==5)&&(to==2)))
				{
					price=200+700;
					System.out.println("PRICE :"+price);
				}
				else if(((from==3)&&(to==4))||((from==4)&&(to==3)))
				{
					price=200+700;
					System.out.println("PRICE :"+price);
				}
				else if(((from==3)&&(to==5))||((from==5)&&(to==3)))
				{
					price=200+700;
					System.out.println("PRICE :"+price);
				}
				else if(((from==4)&&(to==5))||((from==5)&&(to==4)))
				{
					price=200+700;
					System.out.println("PRICE :"+price);
				}
				else
				{
					System.out.println("WRONG DESTINETION ENTERD.");
				}
			break;

			//Local class

			case 3:
				System.out.println("Enter 1 for KOLHAPUR.\nEnter 2 for PUNE.\nEnter 3 for MUMBAI.\nEnter 4 for NAGPUR.\nEnter 5 for BENGALOR.");
				System.out.println("FROM :");
				from=sc.nextInt();
				System.out.println("TO :");
				to=sc.nextInt();

				if(((from==1)&&(to==2))||((from==2)&&(to==1)))
				{
					price=100+200;
					System.out.println("PRICE :"+price);
				}
				else if(((from==1)&&(to==3))||((from==3)&&(to==1)))
				{
					price=100+300;
					System.out.println("PRICE :"+price);
				}
				else if(((from==1)&&(to==4))||((from==4)&&(to==1)))
				{
					price=100+400;
					System.out.println("PRICE :"+price);
				}
				else if(((from==1)&&(to==5))||((from==5)&&(to==1)))
				{
					price=100+500;
					System.out.println("PRICE :"+price);
				}
				else if(((from==2)&&(to==3))||((from==3)&&(to==2)))
				{
					price=100+600;
					System.out.println("PRICE :"+price);
				}
				else if(((from==2)&&(to==4))||((from==4)&&(to==2)))
				{
					price=100+700;
					System.out.println("PRICE :"+price);
				}
				else if(((from==2)&&(to==5))||((from==5)&&(to==2)))
				{
					price=100+700;
					System.out.println("PRICE :"+price);
				}
				else if(((from==3)&&(to==4))||((from==4)&&(to==3)))
				{
					price=100+700;
					System.out.println("PRICE :"+price);
				}
				else if(((from==3)&&(to==5))||((from==5)&&(to==3)))
				{
					price=100+700;
					System.out.println("PRICE :"+price);
				}
				else if(((from==4)&&(to==5))||((from==5)&&(to==4)))
				{
					price=100+700;
					System.out.println("PRICE :"+price);
				}
				else
				{
					System.out.println("WRONG DESTINETION ENTERD.");
				}
			break;

			//Default case.

			default :
				System.out.println("ENTERED TRAIN TYPE IS WRONG");
		}

		//Ticket code.

		System.out.println("YOUR TICKET IS BOOKED.");
		System.out.println("----------------------------");
		System.out.println("FIRST NAME :"+first);
		System.out.println("MIDDLE NAME :"+middle);
		System.out.println("LAST NAME :"+last);
		System.out.println("PHONE NUMBER :"+phone_number);

		if(from==1)
		{	
			System.out.println("FROM :KOLHAPUR.");
		}
		else if(from==2)
		{
			System.out.println("FROM :PUNE");
		}
		else if(from==3)
		{
			System.out.println("FROM :MUMBAI");
		}
		else if(from==4)
		{
			System.out.println("FROM :NAGPUR");
		}
		else if(from==5)
		{
			System.out.println("FROM :BENGALOR");
		}
		if(to==1)
		{	
			System.out.println("TO :KOLHAPUR.");
		}
		else if(to==2)
		{
			System.out.println("To :PUNE");
		}
		else if(to==3)
		{
			System.out.println("TO :MUMBAI");
		}
		else if(to==4)
		{
			System.out.println("TO :NAGPUR");
		}
		else if(to==5)
		{
			System.out.println("TO :BENGALOR");
		}

		//Ticket number code.
	
		System.out.println("Your ticket number is:");
		Random rndm_method=new Random();
		char[]ticket=new char[len];

		for(int i=0;i<len;i++)
		{	
			ticket[i]=numbers.charAt(rndm_method.nextInt(numbers.length()));
		}

		System.out.println(ticket);
		System.out.println("----------------------------");
	}
	
	//Train schedule.

	void schedule()
	{
		System.out.println("\n\t\t\t****** Railway Schedule*******");
		System.out.println("\n\tBus Type\tTime\t\tFrom\t\tTo\tTicket Price");

		//FIRST CLASS

		System.out.println("\t********************************************************************");
		System.out.println("\n\tFirst Class\t9.30 Am\t\tKOLHAPUR\tPUNE\t\t500");
		System.out.println("\n\tFirst Class\t9.30 Am\t\tPUNE    \tKOLHAPUR\t500");
		System.out.println("\t--------------------------------------------------------------------");

		System.out.println("\n\tFirst Class\t10.30 Am\tKOLHAPUR\tMUMBAI\t\t600");
		System.out.println("\n\tFirst Class\t10.30 Am\tMUMBAI   \tKOLHAPUR\t600");
		System.out.println("\t--------------------------------------------------------------------");

		System.out.println("\n\tFirst Class\t11.30 Am\tKOLHAPUR\tNAGPUR \t\t700");
		System.out.println("\n\tFirst Class\t11.30 Am\tNAGPUR   \tKOLHAPUR \t700");
		System.out.println("\t--------------------------------------------------------------------");
		
		System.out.println("\n\tFirst Class\t12.30 Pm\tKOLHAPUR\tBANGALOR\t800");
		System.out.println("\n\tFirst Class\t12.30 Pm\tBAMGALOR\tKOLHAPUR\t800");
		System.out.println("\t--------------------------------------------------------------------");

		System.out.println("\n\tFirst Class\t12.45 Pm\tPUNE     \tMUMBAI\t\t900");
		System.out.println("\n\tFirst Class\t12.45 Pm\tMUMBAI   \tPUNE\t\t900");
		System.out.println("\t--------------------------------------------------------------------");
		
		System.out.println("\n\tFirst Class\t1.00 Pm \tPUNE     \tNAGPUR\t\t1000");
		System.out.println("\n\tFirst Class\t1.00 Pm \tNAGPUR   \tPUNE\t\t1000");
		System.out.println("\t--------------------------------------------------------------------");
		
		System.out.println("\n\tFirst Class\t1.30 Pm\t\tPUNE    \tBANGALOR\t1000");
		System.out.println("\n\tFirst Class\t1.30 Pm\t\tBANALOR \tPUNE\t\t1000");
		System.out.println("\t--------------------------------------------------------------------");
		
		System.out.println("\n\tFirst Class\t2.30 Pm  \tMUMBAI  \tNAGPUR\t\t1000");
		System.out.println("\n\tFirst Class\t2.30 Pm  \tNAGPUR  \tMUMBAI\t\t1000");
		System.out.println("\t--------------------------------------------------------------------");
		
		System.out.println("\n\tFirst Class\t2.45 Pm  \tMUMBAI  \tBANGALOR\t1000");
		System.out.println("\n\tFirst Class\t2.45 Pm  \tBANGALOR\tMUMBAI\t\t1000");
		System.out.println("\t--------------------------------------------------------------------");
		
		System.out.println("\n\tFirst Class\t3.45 Pm  \tNAGPUR  \tBANGALOR\t1000");
		System.out.println("\n\tFirst Class\t3.45 Pm  \tBANGALOR\tNAGPUR\t\t1000");

		//SECOND CLASS

		System.out.println("\t********************************************************************");
		System.out.println("\n\tSecond Class\t9.30 Am\t\tKOLHAPUR\tPUNE\t\t400");
		System.out.println("\n\tsecond Class\t9.30 Am\t\tPUNE    \tKOLHAPUR\t400");
		System.out.println("\t--------------------------------------------------------------------");

		System.out.println("\n\tSecond Class\t10.30 Am\tKOLHAPUR\tMUMBAI\t\t500");
		System.out.println("\n\tSecond Class\t10.30 Am\tMUMBAI  \tKOLHAPUR\t500");
		System.out.println("\t--------------------------------------------------------------------");

		System.out.println("\n\tSecond Class\t11.30 Am\tKOLHAPUR\tNAGPUR \t\t600");
		System.out.println("\n\tSecond Class\t11.30 Am\tNAGPUR  \tKOLHAPUR \t600");
		System.out.println("\t--------------------------------------------------------------------");
		
		System.out.println("\n\tSecond Class\t12.30 Pm\tKOLHAPUR\tBANGALOR\t700");
		System.out.println("\n\tSecond Class\t12.30 Pm\tBAMGALOR\tKOLHAPUR\t700");
		System.out.println("\t--------------------------------------------------------------------");

		System.out.println("\n\tSecond Class\t12.45 Pm\tPUNE    \tMUMBAI\t\t800");
		System.out.println("\n\tSecond Class\t12.45 Pm\tMUMBAI  \tPUNE\t\t800");
		System.out.println("\t--------------------------------------------------------------------");
		
		System.out.println("\n\tSecond Class\t1.00 Pm \tPUNE    \tNAGPUR\t\t900");
		System.out.println("\n\tSecond Class\t1.00 Pm \tNAGPUR  \tPUNE\t\t900");
		System.out.println("\t--------------------------------------------------------------------");
		
		System.out.println("\n\tSecond Class\t1.30 Pm\t\tPUNE   \t\tBANGALOR\t900");
		System.out.println("\n\tSecond Class\t1.30 Pm\t\tBANALOR\t\tPUNE\t\t900");
		System.out.println("\t--------------------------------------------------------------------");
		
		System.out.println("\n\tSecond Class\t2.30 Pm  \tMUMBAI \t\tNAGPUR\t\t900");
		System.out.println("\n\tSecond Class\t2.30 Pm  \tNAGPUR \t\tMUMBAI\t\t900");
		System.out.println("\t--------------------------------------------------------------------");
		
		System.out.println("\n\tSecond Class\t2.45 Pm  \tMUMBAI \t\tBANGALOR\t900");
		System.out.println("\n\tSecond Class\t2.45 Pm  \tBANGALOR\tMUMBAI\t\t900");
		System.out.println("\t--------------------------------------------------------------------");
		
		System.out.println("\n\tSecond Class\t3.45 Pm  \tNAGPUR\t\tBANGALOR\t900");
		System.out.println("\n\tSecond Class\t3.45 Pm  \tBANGALOR\tNAGPUR\t\t900");

		//LOCAL CLASS

		System.out.println("\t********************************************************************");
		System.out.println("\n\tLocal Class\t9.30 Am\t\tKOLHAPUR\tPUNE\t\t300");
		System.out.println("\n\tLocal Class\t9.30 Am\t\tPUNE\t\tKOLHAPUR\t300");
		System.out.println("\t--------------------------------------------------------------------");

		System.out.println("\n\tLocal Class\t10.30 Am\tKOLHAPUR\tMUMBAI\t\t400");
		System.out.println("\n\tLocal Class\t10.30 Am\tMUMBAI\t\tKOLHAPUR\t400");
		System.out.println("\t--------------------------------------------------------------------");

		System.out.println("\n\tLocal Class\t11.30 Am\tKOLHAPUR\tNAGPUR \t\t500");
		System.out.println("\n\tLocal Class\t11.30 Am\tNAGPUR\t\tKOLHAPUR \t500");
		System.out.println("\t--------------------------------------------------------------------");
		
		System.out.println("\n\tLocal Class\t12.30 Pm\tKOLHAPUR\tBANGALOR\t600");
		System.out.println("\n\tLocal Class\t12.30 Pm\tBAMGALOR\tKOLHAPUR\t600");
		System.out.println("\t--------------------------------------------------------------------");

		System.out.println("\n\tLocal Class\t12.45 Pm\tPUNE\t\tMUMBAI\t\t700");
		System.out.println("\n\tLocal Class\t12.45 Pm\tMUMBAI\t\tPUNE\t\t700");
		System.out.println("\t--------------------------------------------------------------------");
		
		System.out.println("\n\tLocal Class\t1.00 Pm \tPUNE\t\tNAGPUR\t\t800");
		System.out.println("\n\tLocal Class\t1.00 Pm \tNAGPUR\t\tPUNE\t\t800");
		System.out.println("\t--------------------------------------------------------------------");
		
		System.out.println("\n\tLocal Class\t1.30 Pm\t\tPUNE\t\tBANGALOR\t800");
		System.out.println("\n\tLocal Class\t1.30 Pm\t\tBANALOR\t\tPUNE\t\t800");
		System.out.println("\t--------------------------------------------------------------------");
		
		System.out.println("\n\tLocal Class\t2.30 Pm  \tMUMBAI\t\tNAGPUR\t\t800");
		System.out.println("\n\tLocal Class\t2.30 Pm  \tNAGPUR\t\tMUMBAI\t\t800");
		System.out.println("\t--------------------------------------------------------------------");
		
		System.out.println("\n\tLocal Class\t2.45 Pm  \tMUMBAI\t\tBANGALOR\t800");
		System.out.println("\n\tLocal Class\t2.45 Pm  \tBANGALOR\tMUMBAI\t\t800");
		System.out.println("\t--------------------------------------------------------------------");
		
		System.out.println("\n\tLocal Class\t3.45 Pm  \tNAGPUR\t\tBANGALOR\t800");
		System.out.println("\n\tLocal Class\t3.45 Pm  \tBANGALOR\tNAGPUR\t\t800");		
		System.out.println("\t********************************************************************");
	}

	//About system.
	void about()
	{
		System.out.println("\n\t\t--------$INDIAN RAILWAYS$---------------------------------------------");
		System.out.println("\n\tType:\tGovernment sector");
		System.out.println("\n\tEsted Since:\t8May 1845");
		System.out.println("\n\tIndusrty type\tRailTransport"); 
		System.out.println("\n\tHeadquaters:\tnew delhi");
		System.out.println("\n\tArea Surved:\toverall india");
		System.out.println("\n\tKey People:\tPiyush goyal[Hon. Railway Minister of india]\n\t\t\tVinayKumar yadav[chairmen of Railway Board]");
		System.out.println("\n\tRevenue:\t1.84 Trilion");
		System.out.println("\n\tDivision:\t17 zones");
		System.out.println("\n\twebsites1:\tindiarail.gov.in");
		System.out.println("\n\twebsites2:\tindiarailways.gov.in");
		System.out.println("\n\n \n\t**********************************************************************");
	}

	//Help option.
	void help()
	{
		System.out.println("\n\t\t ######Help####### ");
		System.out.println("\n\tFAQ's List:");
		System.out.println("\n\t1.How can i avail the enquiries?");
		System.out.println("\n\t2.How can i avail the internet reservation facility?");
		System.out.println("\n\t3.where can i take get latest arrival and depture timings of Train?");
		System.out.println("\n\t4.Why do i get newtwork connectivity failfure problem? ");
		System.out.println("\n\n\tNEED SPECIFIC:");
		System.out.println("\n\t'How do i use Trains between important stations?' ");
		System.out.println("\n\t'Railway Rules' ");
		System.out.println("\n\t'Knowing station codes and Train Numbers' ");
		System.out.println("\n\t\tFOR More information log on to WWW.IRCTC.co.in");
	}
}
//Main menu.
class First extends Background
{
	//first window.

	void page()
	{
		int choice;
		Scanner sc=new Scanner(System.in);
		Background b1=new Background();
		System.out.println("\n\t************* Welcome To IRCTC Railway Reservation System ***********");
		System.out.println("\n\n\t**********MAIN MENU*********");
		System.out.println("Enter 1 for see SHEDULE.\nEnter 2 for BOOK TICKET.\nEnter 3 for see ABOUT.\nEnter 4 for see HELP.");
		choice=sc.nextInt();

		switch(choice)
		{
			
			//First option(Train schedule)

			case 1:
				b1.schedule();
				page();
			break;

			//Second option(Ticket booking)

			case 2:
				b1.Bookticket();
				page();
			break;

			//Third option(About system)

			case 3:
				b1.about();
				page();
			break;
			//Fifth option(Help option)

			case 4:
				b1.help();
				page();
			break;
		}
	}	
}

//Main class
class Firstpage
{
	public static void main(String[] args)
	{
		First f1=new First();
		f1.page();			
	}
}

